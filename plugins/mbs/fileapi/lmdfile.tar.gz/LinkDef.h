#ifdef __CINT__

#pragma link off all globals;
#pragma link off all classes;
#pragma link off all functions;

#pragma link C++ nestedclasses;
#pragma link C++ namespace mbs;
#pragma link C++ class mbs::Header;
#pragma link C++ class mbs::SubeventHeader;
#pragma link C++ class mbs::EventHeader;
#pragma link C++ class mbs::BufferHeader;
#pragma link C++ class mbs::LmdFile;

#endif
