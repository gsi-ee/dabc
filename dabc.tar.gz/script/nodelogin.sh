#!/bin/sh

echo "Simple DABC node login DABCSYS = $DABCSYS"

. $DABCSYS/script/dabclogin-gsi-devel.sh
