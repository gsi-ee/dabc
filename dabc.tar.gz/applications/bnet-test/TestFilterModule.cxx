/********************************************************************
 * The Data Acquisition Backbone Core (DABC)
 ********************************************************************
 * Copyright (C) 2009- 
 * GSI Helmholtzzentrum fuer Schwerionenforschung GmbH 
 * Planckstr. 1
 * 64291 Darmstadt
 * Germany
 * Contact:  http://dabc.gsi.de
 ********************************************************************
 * This software can be used under the GPL license agreements as stated
 * in LICENSE.txt file which is part of the distribution.
 ********************************************************************/
#include "TestFilterModule.h"

#include "dabc/logging.h"
#include "dabc/PoolHandle.h"
#include "dabc/Command.h"
#include "dabc/Port.h"

#include "bnet/common.h"

bnet::TestFilterModule::TestFilterModule(const char* name, dabc::Command* cmd) :
   dabc::ModuleAsync(name, cmd)
{
   fPool = CreatePoolHandle(bnet::EventPoolName);

   CreateInput("Input", fPool, FilterInpQueueSize);

   CreateOutput("Output", fPool, FilterOutQueueSize);
}

void bnet::TestFilterModule::ProcessUserEvent(dabc::ModuleItem*, uint16_t)
{
//   DOUT1(("!!!!!!!! ProcessInputEvent port = %p", port));

   while (Input(0)->CanRecv() && Output(0)->CanSend()) {

      dabc::Buffer* buf = Input(0)->Recv();

      if (buf==0) {
         EOUT(("Fail to receive data from Input"));
         return;
      }

      uint64_t* mem = (uint64_t*) buf->GetDataLocation();
      uint64_t evid = mem[0];

      if (evid % 2) {
    //   DOUT1(("EVENT KILLED %llu", evid));
        dabc::Buffer::Release(buf);
      } else
          Output(0)->Send(buf);
   }
}
