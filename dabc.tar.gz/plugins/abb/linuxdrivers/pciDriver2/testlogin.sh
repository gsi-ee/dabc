#!/bin/bash
export PCISYS=`pwd`

export LD_LIBRARY_PATH=.:$PCISYS/lib:$LD_LIBRARY_PATH
