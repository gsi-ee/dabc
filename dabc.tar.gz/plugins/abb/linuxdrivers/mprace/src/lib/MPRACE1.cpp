/*******************************************************************
 * Change History:
 * 
 * $Log: MPRACE1.cpp,v $
 * Revision 1.4  2008/04/07 16:09:04  adamczew
 * *** empty log message ***
 *
 * Revision 1.1  2007-02-12 18:09:14  marcus
 * Initial commit.
 *
 *******************************************************************/

#include "Board.h"
#include "MPRACE1.h"

using namespace mprace;

