#ifdef __CINT__

#pragma link off all globals;
#pragma link off all classes;
#pragma link off all functions;

#pragma link C++ class TRocParam+;
#pragma link C++ class TRocProc+;
#pragma link C++ class SysCoreData;

#endif



