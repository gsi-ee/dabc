#!/usr/bin/ksh
echo useranalysis startup script
echo $1
./$1 $2 $3 $4 $5 $6
echo "-----------------------------------------"
echo done ...
sleep 1
