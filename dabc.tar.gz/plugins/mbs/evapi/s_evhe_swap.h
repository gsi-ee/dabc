#ifndef F_EVHE_SWAP
#define F_EVHE_SWAP


#include "typedefs.h"
typedef struct
{
INTS4  l_dlen;   /*  Length of data in words */
INTS2 i_type;
INTS2 i_subtype;
} s_evhe;


#endif
