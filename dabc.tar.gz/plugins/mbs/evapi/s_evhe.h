#include "typedefs.h"
/* Generated from EE$ROOT:[GOOFY.VME]SA$EVHE.VMETEMP;  */
/* Swapping enabled           */
  /*  ================= GSI VME General event header ===============  */
typedef struct
{
INTS4  l_dlen;   /*  Length of data in words */
INTS2 i_subtype;
INTS2 i_type;
} s_evhe;
  /* ------------------------------------------------------------------ */
