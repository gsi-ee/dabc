/********************************************************************
 * The Data Acquisition Backbone Core (DABC)
 ********************************************************************
 * Copyright (C) 2009- 
 * GSI Helmholtzzentrum fuer Schwerionenforschung GmbH 
 * Planckstr. 1
 * 64291 Darmstadt
 * Germany
 * Contact:  http://dabc.gsi.de
 ********************************************************************
 * This software can be used under the GPL license agreements as stated
 * in LICENSE.txt file which is part of the distribution.
 ********************************************************************/
#include "typedefs.h"
#define COMPR__PATTERN 0x0f0f0f0f
typedef struct
{
INTU4 l_endian;     /* set to 1 by creator */
INTU4 l_length;     /* total size [bytes] of compressed buffer */
INTU4 l_masks;      /* number of masks following this header */
INTU4 l_full_bytes; /* number of bytes needed for uncompressed buffer */
INTU4 l_comp_bytes; /* number of non zero bytes */
INTU4 l_pattern;    /* COMPR__PATTERN */
} s_compress;
INTS4 f_ut_compr_size(INTU1 *, INTS4);
INTS4 f_ut_compr_zeros(INTU1 *, INTS4);
INTS4 f_ut_compr_pack(INTU1 *, INTS4, INTU1 *, INTS4);
INTS4 f_ut_compr_unpack(INTU1 *, INTU1 *, INTS4);
