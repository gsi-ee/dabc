/* identities for filter patterns                */
struct s_pat1
             {
             short         i_trigger;
             short         i_dummy;
             };

struct s_pat2
             {
             short         i_procid;
             char          h_subcrate;
             char          h_control;
             };

struct s_pat3
             {
             short         i_type;
             short         i_subtype;
             };
