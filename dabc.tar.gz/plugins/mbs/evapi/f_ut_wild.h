#include "typedefs.h"
INTS4 f_ut_wild(CHARS *, CHARS *);
