#ifndef F_SWAPLW
#define F_SWAPLW

#include "typedefs.h"
INTS4 f_swaplw(INTS4 *pp_source, INTS4 l_len, INTS4 *pp_dest);

#endif
